# Додано підтримку DI_Overflow_OK у симуляторі норії

**Дата:** 2026-02-15  
**Версія:** 2.1.0  
**Контекст:** Додано сигнал DI_Overflow_OK до UDT_Noria, необхідно оновити симулятор

---

## 📋 Зміст

- [Огляд змін](#огляд-змін)
- [Оновлені файли](#оновлені-файли)
- [Архітектура симуляції overflow](#архітектура-симуляції-overflow)
- [Використання](#використання)
- [Тестування](#тестування)

---

## Огляд змін

### Проблема
У структурі `UDT_Noria` був доданий сигнал `DI_Overflow_OK` для моніторингу переповнення, але симулятор `FC_SimNoria` не симулював цей сигнал.

**Наслідок:** При тестуванні без реального залізаварія FLT_OVERFLOW ніколи не виникала, бо DI_Overflow_OK завжди був FALSE (не ініціалізований).

### Рішення
Додано повну підтримку симуляції overflow до симулятора норії, аналогічно до симуляторів redler та інших аварій (breaker, alignment).

**Аварії норії (повний список):**
1. ✅ DI_Breaker_OK - аварія автомата захисту
2. ✅ DI_Alingment_OK - аварія вирівнювання стрічки (typo збережено для сумісності)
3. ✅ DI_Overflow_OK - **аварія переповнення (нове!)**
4. ✅ DI_Speed_OK - втрата швидкості (не латчована)

---

## Оновлені файли

### 1. UDT_SimNoriaConfig.scl (v2.1.0)

**Зміни:**
- ✅ Додано `SimFault_Overflow : BOOL` - прапор увімкнення симуляції
- ✅ Додано `FaultTime_Overflow_ms : DINT` - час до спрацювання аварії
- 🔧 Зменшено кількість резервних полів (Reserved1..3)

**Приклад використання:**
```scl
// У DB_SimConfig
Noria[0].SimFault_Overflow := TRUE;      // увімкнути симуляцію
Noria[0].FaultTime_Overflow_ms := 15000; // аварія через 15 сек після пуску
```

---

### 2. UDT_SimNoriaState.scl (v2.1.0)

**Зміни:**
- ✅ Додано `Overflow_Tripped : BOOL` - латч аварії переповнення
- 🔧 Зменшено кількість резервних полів

**Поведінка латча:**
- `Overflow_Tripped = TRUE` → встановлюється при спрацюванні таймера
- Скидається тільки через `ManualReset = TRUE`
- `DI_Overflow_OK = NOT Overflow_Tripped` (інверсія)

---

### 3. FC_SimNoria.scl (v2.1.0)

**Зміни:**
- ✅ Додано PHASE 5: Симуляція аварії OVERFLOW
- ✅ Додано параметри `SimFault_Overflow` та `FaultTime_Overflow_ms`
- ✅ Додано скидання `Overflow_Tripped` у PHASE 0 (ManualReset)
- ✅ Додано запис `DI_Overflow_OK`

**Логіка симуляції:**
```
1. Мотор запускається (DO_Run: 0→1)
   └─ FaultStartTck = TIME_TCK()

2. Мотор працює + SimFault_Overflow = TRUE
   └─ Таймер рахує від FaultStartTck

3. Таймаут досяг FaultTime_Overflow_ms
   └─ Overflow_Tripped = TRUE (латч)

4. DI_Overflow_OK = NOT Overflow_Tripped
   └─ FC_Noria бачить DI_Overflow_OK = FALSE
   └─ FLTCode = FLT_OVERFLOW, Status = STS_FAULT
```

---

### 4. DB_SimConfig.scl (v2.1.0)

**Зміни:**
- ✅ Додано ініціалізацію `SimFault_Overflow` та `FaultTime_Overflow_ms` для норій 0, 1, 2
- 📝 Оновлено коментарі версії

**Приклад конфігурації:**
```scl
// Норія 0 - типова конфігурація
Noria[0].Enable := TRUE;
Noria[0].StartupTime_ms := 4000;
Noria[0].StopTime_ms := 3000;
Noria[0].SimFault_Breaker := FALSE;
Noria[0].FaultTime_Breaker_ms := 10000;
Noria[0].SimFault_Alignment := FALSE;
Noria[0].FaultTime_Alignment_ms := 20000;
Noria[0].SimFault_Overflow := FALSE;       // ⬅️ НОВЕ!
Noria[0].FaultTime_Overflow_ms := 15000;   // ⬅️ НОВЕ!
Noria[0].ManualReset := FALSE;
```

---

## Архітектура симуляції overflow

### Аналогія з Redler
Overflow у норії симулюється аналогічно до overflow у редлері:

| Параметр | Redler | Noria | Примітка |
|----------|--------|-------|----------|
| Типовий час | 15 сек | 15 сек | Може налаштовуватись |
| Латч | ✅ Так | ✅ Так | До ManualReset |
| Пріоритет | 2-й (після Breaker) | 3-й (Breaker→Overflow→Alignment) | У FC_Noria |
| Force code | BIT0 (1) | BIT1 (2) | У FC_Noria |

### Порівняння з іншими аваріями

**Breaker (автомат захисту):**
- Пріоритет: 1 (найвищий)
- Типовий час: 10 сек
- Фізичний аналог: спрацювання автомата через перевантаження

**Overflow (переповнення):**
- Пріоритет: 2
- Типовий час: 15 сек
- Фізичний аналог: датчик рівня спрацював

**Alignment (вирівнювання стрічки):**
- Пріоритет: 3 (найнижчий)
- Типовий час: 20 сек
- Фізичний аналог: стрічка зійшла з ролика

**Speed (швидкість):**
- Пріоритет: 4
- НЕ латчована (умовна аварія)
- Фізичний аналог: датчик швидкості не спрацював при пуску

---

## Використання

### 1. Базова симуляція (без аварій)
```scl
// OB1 (Main)
"FC_SimNoria"(
    NoriaIdx := 0,
    StartupTime_ms := 7000,      // розгін 7 сек
    StopTime_ms := 3000,         // вибіг 3 сек
    SimFault_Breaker := FALSE,   // без аварії breaker
    SimFault_Alignment := FALSE, // без аварії alignment
    SimFault_Overflow := FALSE,  // без аварії overflow
    ManualReset := FALSE
);
```

**Очікувана поведінка:**
- Норія запускається через CMD_START
- DI_Speed_OK стає TRUE через 7 секунд
- Норія зупиняється через CMD_STOP
- DI_Speed_OK стає FALSE через 3 секунди
- Жодних аварій не виникає

---

### 2. Симуляція overflow (для тестування)
```scl
// OB1 (Main)
"FC_SimNoria"(
    NoriaIdx := 0,
    StartupTime_ms := 7000,
    StopTime_ms := 3000,
    SimFault_Breaker := FALSE,
    SimFault_Alignment := FALSE,
    SimFault_Overflow := TRUE,      // ⬅️ увімкнути overflow
    FaultTime_Overflow_ms := 15000, // ⬅️ через 15 сек після пуску
    ManualReset := FALSE
);
```

**Очікувана поведінка:**
1. Норія запускається (DO_Run = TRUE)
2. Через 7 сек: DI_Speed_OK = TRUE (розгін завершено)
3. Status = STS_RUNNING
4. Через 15 сек від пуску: **DI_Overflow_OK = FALSE**
5. FC_Noria бачить аварію → FLTCode = FLT_OVERFLOW
6. Status = STS_FAULT
7. DO_Run = FALSE (мотор вимикається)

---

### 3. Скидання аварії
```scl
// Варіант 1: Через параметр функції (разовий імпульс)
"FC_SimNoria"(
    NoriaIdx := 0,
    ...
    ManualReset := TRUE,  // ⬅️ скинути всі латчі
    ...
);

// Варіант 2: Через HMI (кнопка Reset)
DB_SimConfig.Noria[0].ManualReset := TRUE;  // встановити через HMI
// ... на наступному циклі
DB_SimConfig.Noria[0].ManualReset := FALSE; // автоматично скинути
```

**Важливо:** ManualReset скидає **всі** латчовані аварії:
- Breaker_Tripped
- Alignment_Tripped
- Overflow_Tripped

---

### 4. Множинні аварії (пріоритет)
```scl
// OB1 (Main)
"FC_SimNoria"(
    NoriaIdx := 0,
    StartupTime_ms := 7000,
    StopTime_ms := 3000,
    SimFault_Breaker := TRUE,       // breaker через 10 сек
    FaultTime_Breaker_ms := 10000,
    SimFault_Overflow := TRUE,      // overflow через 15 сек
    FaultTime_Overflow_ms := 15000,
    SimFault_Alignment := TRUE,     // alignment через 20 сек
    FaultTime_Alignment_ms := 20000,
    ManualReset := FALSE
);
```

**Очікувана поведінка:**
1. Норія запускається
2. Через 10 сек: **FLT_BREAKER спрацює першим** (пріоритет 1)
3. Overflow/Alignment НЕ встановляться, бо FC_Noria вже у FAULT

**Пріоритет у FC_Noria (REGION 3):**
```scl
IF NOT #N.DI_Breaker_OK THEN
    #B.FLTCode := "FLT_BREAKER";      // Пріоритет 1
ELSIF NOT #N.DI_Overflow_OK THEN
    #B.FLTCode := "FLT_OVERFLOW";     // Пріоритет 2
ELSIF NOT #N.DI_Alingment_OK THEN
    #B.FLTCode := "FLT_ALINGMENT";    // Пріоритет 3
END_IF;
```

---

## Тестування

### Acceptance Test Case 1: Overflow спрацювання

**Arrange:**
```
- Норія 0 у стані IDLE
- SimFault_Overflow = TRUE
- FaultTime_Overflow_ms = 10000 (10 сек для швидкого тесту)
```

**Act:**
```
1. CMD_START → норія починає розгін
2. Чекаємо 10 секунд
```

**Assert:**
```
✅ DI_Overflow_OK = FALSE
✅ FLTCode = FLT_OVERFLOW
✅ Status = STS_FAULT
✅ DO_Run = FALSE
✅ Overflow_Tripped = TRUE (у DB_SimMechs.Noria[0])
```

---

### Acceptance Test Case 2: ManualReset

**Arrange:**
```
- Норія 0 у стані FAULT
- FLTCode = FLT_OVERFLOW
- Overflow_Tripped = TRUE
```

**Act:**
```
ManualReset = TRUE (один цикл)
```

**Assert:**
```
✅ Overflow_Tripped = FALSE
✅ DI_Overflow_OK = TRUE
✅ Можна виконати CMD_RESET у FC_Noria
✅ Status → IDLE
✅ FLTCode → FLT_NONE
```

---

### Acceptance Test Case 3: Overflow не спрацьовує після зупинки

**Arrange:**
```
- Норія 0 запущена
- SimFault_Overflow = TRUE
- FaultTime_Overflow_ms = 20000
```

**Act:**
```
1. CMD_START → норія запускається
2. Через 10 сек: CMD_STOP → норія зупиняється
3. Чекаємо ще 15 секунд (загалом 25 сек від пуску)
```

**Assert:**
```
✅ DI_Overflow_OK = TRUE (аварія НЕ спрацювала)
✅ Overflow_Tripped = FALSE
✅ Причина: таймер рахує тільки при IsMotorRunning = TRUE
```

---

### Unit Test (FB_Test_Noria)

**Додатковий тест-кейс для overflow:**
```scl
// N1: Overflow аварія
21:
    N.DI_Overflow_OK := FALSE;
    Exp_Status := "DB_Const".STS_FAULT;
    Exp_FLTCode := "DB_Const".FLT_OVERFLOW;

// N2: Overflow > Alignment (пріоритет)
22:
    N.DI_Overflow_OK := FALSE;
    N.DI_Alingment_OK := FALSE;
    Exp_Status := "DB_Const".STS_FAULT;
    Exp_FLTCode := "DB_Const".FLT_OVERFLOW;

// N3: Форс OVERFLOW
23:
    N.DI_Overflow_OK := FALSE;
    N.Base.Force_Code := 2; // BIT1
    Exp_Status := "DB_Const".STS_IDLE;
```

---

## Зміни у контракті

### Оновлення Section 9.3 (Fault Priority)

**Норія (Noria):**
```
1. FLT_BREAKER   (BIT0 force)
2. FLT_OVERFLOW  (BIT1 force) ⬅️ НОВЕ!
3. FLT_ALINGMENT (BIT3 force)
4. FLT_NO_RUNFB  (BIT2 force)
```

**Зміна:** Overflow тепер **2-й пріоритет** (було тільки 3 типи аварій).

---

## Висновок

### ✅ Що додано:
1. Повна підтримка симуляції DI_Overflow_OK у FC_SimNoria
2. Конфігураційні параметри у UDT_SimNoriaConfig
3. Латч аварії у UDT_SimNoriaState
4. Оновлено DB_SimConfig з налаштуваннями overflow
5. Документація та приклади використання

### 🎯 Переваги:
- ✅ Можна тестувати FLT_OVERFLOW без реального заліза
- ✅ Узгодженість з симуляторами інших типів механізмів
- ✅ Гнучкість налаштування через конфігурацію
- ✅ Підтримка ManualReset для скидання аварії

### 📋 Checklist впровадження:
- [ ] Імпортувати оновлені UDT до проекту TIA Portal
- [ ] Оновити FC_SimNoria
- [ ] Перекомпілювати DB_SimConfig та DB_SimMechs
- [ ] Оновити HMI екрани (якщо є індикація overflow)
- [ ] Додати тест-кейси до FB_Test_Noria (опціонально)
- [ ] Перевірити, що FC_Noria коректно обробляє DI_Overflow_OK (вже є)

---

**Версія документації:** 1.0  
**Автор:** Engineering Team  
**Дата:** 2026-02-15
